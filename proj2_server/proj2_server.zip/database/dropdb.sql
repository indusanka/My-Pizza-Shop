drop table if exists administrators;
drop table if exists systemDay;
drop table if exists orderItems;
drop table if exists orders;
drop table if exists customers;
drop table if exists products;
drop table if exists categories;
drop table if exists addresses;
