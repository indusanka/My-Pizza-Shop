<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?> My Pizza Shop, Inc.
    </p>
</footer>
</body>
</html>