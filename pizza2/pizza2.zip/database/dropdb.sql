-- for use where we can't drop the whole database
-- drop targets of FKs after tables with the FKs
drop table order_topping;	
drop table pizza_orders;
drop table pizza_size;			
drop table toppings;	
drop table pizza_sys_tab;



