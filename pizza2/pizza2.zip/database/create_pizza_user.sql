GRANT SELECT, INSERT, DELETE, UPDATE
ON pizzadb.*
TO pizza_user@localhost
IDENTIFIED BY 'pa55word';
