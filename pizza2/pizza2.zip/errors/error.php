<!DOCTYPE html>
<html>
    <body>
        <main>
            <h1>Error</h1>
            <p class="first_paragraph"><?php echo $error; ?></p>
        </main>
    </body>
</html>
